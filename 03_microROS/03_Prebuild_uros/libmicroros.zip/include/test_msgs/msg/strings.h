// generated from rosidl_generator_c/resource/idl.h.em
// with input from test_msgs:msg/Strings.idl
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__MSG__STRINGS_H_
#define TEST_MSGS__MSG__STRINGS_H_

#include "test_msgs/msg/detail/strings__struct.h"
#include "test_msgs/msg/detail/strings__functions.h"
#include "test_msgs/msg/detail/strings__type_support.h"

#endif  // TEST_MSGS__MSG__STRINGS_H_
