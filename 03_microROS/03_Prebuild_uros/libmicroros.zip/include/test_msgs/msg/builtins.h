// generated from rosidl_generator_c/resource/idl.h.em
// with input from test_msgs:msg/Builtins.idl
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__MSG__BUILTINS_H_
#define TEST_MSGS__MSG__BUILTINS_H_

#include "test_msgs/msg/detail/builtins__struct.h"
#include "test_msgs/msg/detail/builtins__functions.h"
#include "test_msgs/msg/detail/builtins__type_support.h"

#endif  // TEST_MSGS__MSG__BUILTINS_H_
