// generated from rosidl_generator_c/resource/idl.h.em
// with input from test_msgs:msg/BasicTypes.idl
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__MSG__BASIC_TYPES_H_
#define TEST_MSGS__MSG__BASIC_TYPES_H_

#include "test_msgs/msg/detail/basic_types__struct.h"
#include "test_msgs/msg/detail/basic_types__functions.h"
#include "test_msgs/msg/detail/basic_types__type_support.h"

#endif  // TEST_MSGS__MSG__BASIC_TYPES_H_
